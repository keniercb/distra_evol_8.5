--factura 18248
SELECT * FROM mod_logistica.dat_documento WHERE iddocumento = 1136220;

update mod_logistica.dat_documento set estado = 4 -- antes 7
	WHERE iddocumento = 1136220;

SELECT * FROM mod_logfacturacion.dat_docfactura
WHERE 
	nrofactura = 18248 and	
	importetotal = 25000.000000 and
    idcliente = 990000011542 /*and
	idcentrocosto = 990000004576 and
    fechavencimiento = '2025-09-15'*/
	;

delete from mod_logistica.dat_documento
WHERE iddocumento = 1138539 and estado = 8;
