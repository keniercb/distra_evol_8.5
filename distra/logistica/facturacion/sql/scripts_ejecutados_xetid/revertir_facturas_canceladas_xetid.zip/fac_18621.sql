--factura 18621
SELECT * FROM mod_logistica.dat_documento WHERE iddocumento = 1136623;

update mod_logistica.dat_documento 
	set estado = 4 -- antes 7
	, idcomprobante = null
	WHERE iddocumento = 1136623;

SELECT * FROM mod_logfacturacion.dat_docfactura
WHERE 
	nrofactura = 18621 and	
	importetotal = 2398.62 and
    idcliente = 990000012821 /*and
	idcentrocosto = 990000004576 and
    fechavencimiento = '2025-09-15'*/
	;

delete from mod_logistica.dat_documento
WHERE iddocumento = 1138465 and estado = 8;
