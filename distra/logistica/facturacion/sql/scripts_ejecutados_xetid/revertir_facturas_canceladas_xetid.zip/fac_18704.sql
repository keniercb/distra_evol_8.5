--factura 18704
SELECT * FROM mod_logistica.dat_documento WHERE iddocumento = 1136721;

update mod_logistica.dat_documento 
	set estado = 4 -- antes 7
	, idcomprobante = null
	WHERE iddocumento = 1136721;

SELECT * FROM mod_logfacturacion.dat_docfactura
WHERE 
	nrofactura = 18704 and	
	importetotal = 3409.68 and
    idcliente = 990000012821 /*and
	idcentrocosto = 990000004576 and
    fechavencimiento = '2025-09-15'*/
	;

delete from mod_logistica.dat_documento
WHERE iddocumento = 1138467 and estado = 8;
