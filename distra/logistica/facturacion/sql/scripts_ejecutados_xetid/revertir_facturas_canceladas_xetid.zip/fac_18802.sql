--factura 18802
SELECT * FROM mod_logistica.dat_documento WHERE iddocumento = 1136827;
update mod_logistica.dat_documento set estado = 4 -- antes 7
	WHERE iddocumento = 1136827;

SELECT * FROM mod_logfacturacion.dat_docfactura
WHERE 
	--idfactura = 1136827
	importetotal = 11671.860000 and
    idcliente = 990000011257 and
	idcentrocosto = 990000004576 and
    fechavencimiento = '2025-09-15' and 
	nrofactura = 18802;

delete from mod_logistica.dat_documento
WHERE iddocumento = 1138471;
