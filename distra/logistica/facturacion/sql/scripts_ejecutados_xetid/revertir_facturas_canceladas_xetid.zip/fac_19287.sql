--factura 19287
SELECT * FROM mod_logistica.dat_documento WHERE iddocumento = 1137443;

update mod_logistica.dat_documento 
	set estado = 4 -- antes 7
	,idcomprobante = null
	WHERE iddocumento = 1137443;

SELECT * FROM mod_logfacturacion.dat_docfactura
WHERE 
	nrofactura = 19287 and	
	importetotal = 1054.08 and
    idcliente = 990000014758 /*and
	idcentrocosto = 990000004576 and
    fechavencimiento = '2025-09-15'*/
	;

delete from mod_logistica.dat_documento
WHERE iddocumento = 1138512 and estado = 8;
