--factura 19493
SELECT * FROM mod_logistica.dat_documento WHERE iddocumento = 1137684;

update mod_logistica.dat_documento 
	set estado = 4 -- antes 7
	, idcomprobante = null
	WHERE iddocumento = 1137684;

SELECT * FROM mod_logfacturacion.dat_docfactura
WHERE 
	nrofactura = 19493 and	
	importetotal = 12060.58 and
    idcliente = 990000010665 /*and
	idcentrocosto = 990000004576 and
    fechavencimiento = '2025-09-15'*/
	;

delete from mod_logistica.dat_documento
WHERE iddocumento = 1138455 and estado = 8;
