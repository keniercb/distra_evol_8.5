<?php

/**
 * @class ReclamacionModel
 * (Descripcion de la clase, objetivo)
 * @package Inventario
 * @subpackage Entrada
 * @author Dainier Aguila Medina
 * @copyright XETID
 * @version 1.0
 */
class ReclamacionModel extends EntradaModel
{
    public function __construct($datos = array())
    {
        parent::__construct($datos);
        $this->tryInyector();
    }

    /**
     * Devuelve los documentos dado los criterios de búsqueda especificados.
     * @param array $datosDoc Arreglo de datos del documento con sus preductos.
     * @return array
     */
    public function devolverDocumentos($datosDoc = array(), $dql = false)
    {
        $query = parent::devolverDocumentos($datosDoc);
        $reclamacion = new DatReclamacion();
        $reclamacion->getJoinDatReclamacion($query, $datosDoc, 'd');
        $this->cargarTransportador($query, 'd2');
        if ($dql) {
            return $query;
        }
        return array(
            'cantidad' => $query->count(),
            'datos' => $this->cargarClientesDocumentos(
                $this->doctrineHelper->addQueryLimits($query, $datosDoc)->fetchArray()
            )
        );
    }

    /**
     * Adiciona un documento.
     * @param array $datosDoc Arreglo de datos del documento con sus preductos.
     * @return int iddocumento
     */
    public function adicionarDocumento($datosDoc = array())
    {
        $documento = parent::adicionarDocumento($datosDoc);
        $reclamacion = new DatReclamacion();
        if ($datosDoc['iddocumento']) {
            $reclamacion->assignIdentifier($datosDoc['iddocumento']);
        }
        $reclamacion->synchronizeWithArray($datosDoc);
        $documento->DatReclamacion = $reclamacion;
        $documento->save();
        $docPadre = Doctrine::getTable('DatDocumentoPadre')
            ->findByDql('iddocumento = ? AND idpadre = ?', array($documento->iddocumento, $datosDoc['idrecepcion']))
            ->toArray();
        if (!$docPadre) {
            $docPadre = new DatDocumentoPadre();
            $docPadre->synchronizeWithArray(
                array('iddocumento' => $documento->iddocumento, 'idpadre' => $datosDoc['idrecepcion'])
            );
            $docPadre->save();
        }
        $this->trazaDocumento->guardarTraza('Documento adicionado', $documento->iddocumento);
        if (is_array($datosDoc['idproductos']) && count($datosDoc['idproductos']) > 0) {
            $this->getProductoModel()->adicionarMovimientos(
                $documento->iddocumento, $datosDoc['idproductos'], LogisticaMovimientoModel::SIGNO_NINGUNO
            );
        }
        if (is_array($datosDoc['productos']) && count($datosDoc['productos']) > 0) {
            $this->producto->modificarMovimientos($datosDoc['productos']);
        }
        return $documento->iddocumento;
    }

    /**
     * @param Integer $iddocumento Identificador del documento a aprobar
     * @return boolean
     */
    public function aprobarDocumento($iddocumento)
    {
        parent::aprobarDocumento($iddocumento, true);
        return true;
    }

    /**
     * Duplica el documento seleccionado.
     * @param int $iddocumento Indentificador del documento.
     * @return int
     */
    public function copiarDocumento($iddocumento)
    {
        $idCopia = parent::copiarDocumento($iddocumento);
        $reclamacion = Doctrine::getTable('DatReclamacion')->find($iddocumento);
        $nuevoDoc = $reclamacion->copy();
        $datos = $reclamacion->toArray();
        $datos['iddocumento'] = $idCopia;
        $nuevoDoc->synchronizeWithArray($datos);
        $nuevoDoc->save();
        $doc = Doctrine::getTable('DatDocumento')->find($idCopia);
        $docPadre = new DatDocumentoPadre();
        $docPadre->synchronizeWithArray(
            array('iddocumento' => $idCopia, 'idpadre' => $datos['idrecepcion'])
        );
        $docPadre->save();
        $docPadre = new DatDocumentoPadre();
        $docPadre->synchronizeWithArray(
            array('iddocumento' => $idCopia, 'idpadre' => $iddocumento)
        );
        $docPadre->save();
        $this->trazaDocumento->guardarTraza('Documento duplicado', $idCopia);
        return array(
            'iddocumento' => $nuevoDoc->iddocumento,
            'observaciones' => $doc->observaciones
        );
    }

    /**
     * Devuelve los movimientos de un documento.
     * @param array $filtro
     */
    public function devolverMovimientos($filtro)
    {
        if ($filtro['productos']) {
            $filtro['asentado'] = true;
            $query = $this->getProductoModel()->cargarProductos($filtro, true)
                ->leftJoin(
                    "p.DatMovimientos _m ON (_m.iddocumento = {$filtro['idrecepcion']} "
                    . "AND _m.idproducto = p.idproducto)"
                )
                ->addWhere('_m.idmovimiento IS NULL');
        } else {
            $query = $this->getProductoModel()->devolverMovimientos($filtro, true);
            if ($filtro['idreclamacion']) {
                $query->innerJoin('mov.DatRecepcion r')
                    ->innerJoin('r.DatDocumentoPadre dp ON (r.iddocumento = dp.idpadre)')
                    ->leftJoin('dp.DatDocumento d ON (d.iddocumento = dp.iddocumento)')
                    ->leftJoin('d.DatReclamacion rc')
                    ->leftJoin(
                        'rc.DatMovimientos m2 ON (m2.iddocumento = rc.iddocumento AND m2.idproducto = mov.idproducto)'
                    )
                    ->addWhere('d.iddocumento = ? AND m2.idmovimiento IS NULL', $filtro['idreclamacion']);
            } else {
                $query->addSelect('(m.idmovimiento IS NULL) AS enfalta, (mr.idmovimiento IS NOT NULL) AS porfactura')
                    ->leftJoin('mov.DatReclamacion rc')
                    ->leftJoin('rc.DatDocumentoPadre dp ON (rc.iddocumento = dp.iddocumento)')
                    ->leftJoin('dp.DatDocumento d ON (d.iddocumento = dp.idpadre)')
                    ->leftJoin('d.DatRecepcion r')
                    ->leftJoin('r.DatMovimientos m ON (m.iddocumento = r.iddocumento AND m.idproducto = mov.idproducto)')
                    ->leftJoin('m.DatMovrecepcion mr');
            }
        }
        $maestroP = new MaestroProductoModel();
        return array(
            'cantidad' => $query->count(),
            'datos' => $maestroP->addSelectionData($this->doctrineHelper->addQueryLimits($query, $filtro)->fetchArray())
        );
    }

    /**
     * Verifica que los productos del documento tengan cantidades registradas.
     * @param numeric $iddocumento
     * @return boolean
     */
    public function productosConCantidad($iddocumento)
    {
        $query = Doctrine_Query::create()
            ->select('m.idmovimiento')
            ->from('DatMovimientos m')
            ->leftJoin('m.DatMovdiferencia md')
            ->leftJoin('m.DatMovdiferenciacalidad mdc')
            ->where('m.iddocumento = ? AND md.idmovimiento IS NULL AND mdc.idmovimiento IS NULL', array($iddocumento));
        if ($query->count()) {
            return false;
        }
        return true;
    }

    /**
     * @param array $filtro
     * @return array
     */
    public function cargarDiferenciasXCantidad($filtro)
    {
        $query = Doctrine_Query::create()
            ->select(
                'm.idmovimiento, md.signo AS signo, md.cantidaddiferencia AS cantidaddiferencia, '
                . 'coalesce(md.preciodiferencia, 0) AS preciodiferencia, '
                . 'coalesce(md.importediferencia, 0) AS importediferencia, '
                . 'coalesce(md.preciodiferenciaalt, 0) AS preciodiferenciaalt, '
                . 'coalesce(md.importediferenciaalt, 0) AS importediferenciaalt'
            )
            ->from('DatMovimientos m')
            ->leftJoin('m.DatMovdiferencia md')
            ->where('m.idmovimiento = ?', array($filtro['idmovimiento']));
        if ($filtro['dif']) {
            $query->addSelect("m2.cantidad AS cantidad")
                ->innerJoin('m.DatDocumento d')
                ->innerJoin('d.DatReclamacion rc')
                ->innerJoin('d.DatDocumentoPadre dp ON (dp.iddocumento = d.iddocumento)')
                ->innerJoin('dp.DatDocumento d2 ON (d2.iddocumento = dp.idpadre)')
                ->innerJoin('d2.DatRecepcion r2')
                ->innerJoin('r2.DatMovimientos m2');
        } else {
            $query->addSelect('m.cantidad');
        }
        return array('datos' => $query->fetchArray()[0]);
    }

    /**
     * @param numeric $idmovimiento
     * @return array
     */
    public function cargarDiferenciasXCalidad($idmovimiento)
    {
        $total = Doctrine_Query::create()
            ->select('m2.idmovimiento AS idmovimiento, m2.cantidad AS cantidad')
            ->from('DatMovimientos m')
            ->innerJoin('m.DatDocumento d')
            ->innerJoin('d.DatReclamacion rc')
            ->innerJoin('d.DatDocumentoPadre dp ON (dp.iddocumento = d.iddocumento)')
            ->innerJoin('dp.DatDocumento d2 ON (d2.iddocumento = dp.idpadre)')
            ->innerJoin('d2.DatRecepcion r ON (r.iddocumento = d2.iddocumento)')
            ->innerJoin('d2.DatMovimientos m2')
            ->where('m.idmovimiento = ? AND m.idproducto = m2.idproducto', $idmovimiento)
            ->fetchArray();
        $query = Doctrine_Query::create()->from("DatMovdiferenciacalidad dmd")
            ->select("dmd.idmovdiferenciacalidad, dmd.idmovimiento, dmd.idcalidad, dmd.cantidaddiferencia")
            ->where("dmd.idmovimiento = ?", $idmovimiento)
            ->orderBy("dmd.idmovdiferenciacalidad DESC");
        return array(
            'total' => $total[0]['cantidad'],
            'cantidad' => $query->count(),
            'datos' => $this->logisticaDoctrine->addQueryLimits($query)->fetchArray()
        );
    }

    /**
     * Registra las diferencias de los movimientos.
     * @param array $datos
     * @param boolean $varios [Opcional] Determina si se registra diferencias a varios movimientos.
     * @return boolean
     */
    public function registrarDiferencias($datos, $varios = false)
    {
        $movimientos = $varios ? $datos : array($datos);
        foreach ($movimientos as $item) {
            if (!$item['signo'] && $item['preciodiferencia'] <= 0 && $item['preciodiferenciaalt'] <= 0) {
                Doctrine_Query::create()->delete('DatMovdiferencia')->where('idmovimiento = ?', $item['idmovimiento'])
                    ->execute();
            } else {
                $diferencia = new DatMovdiferencia();
                $obj = Doctrine::getTable('DatMovdiferencia')->find($item['idmovimiento']);
                if ($obj) {
                    $diferencia->assignIdentifier($item['idmovimiento']);
                }
                $item['cantidaddiferencia'] = $item['cantidaddiferencia'] ? $item['cantidaddiferencia'] : 0;
                $diferencia->synchronizeWithArray($item);
                $diferencia->save();
            }
            $collection = new Doctrine_Collection('DatMovdiferenciacalidad');
            foreach ($item['calidad'] as $value) {
                if (!$value['eliminar']) {
                    $calidad = new DatMovdiferenciacalidad();
                    if ($value['idmovdiferenciacalidad']) {
                        $calidad->assignIdentifier($value['idmovdiferenciacalidad']);
                    }
                    $calidad->synchronizeWithArray($value);
                    $collection->add($calidad);
                } else {
                    Doctrine_Query::create()->delete('DatMovdiferenciacalidad')
                        ->where('idmovdiferenciacalidad = ?', $value['idmovdiferenciacalidad'])->execute();
                }
            }
            if ($collection->count()) {
                $collection->save();
            }
            if ($item['dif']) {
                $mdc = Doctrine_Query::create()
                    ->select('sum(mdc.cantidaddiferencia) AS cantidad')->from('DatMovdiferenciacalidad mdc')
                    ->where('mdc.idmovimiento = ?', array($item['idmovimiento']))
                    ->fetchArray();
                $item['cantidaddiferencia'] += $mdc[0]['cantidad'];
                Doctrine_Query::create()->update('DatMovimientos')
                    ->set('importecontable', '? * preciocontable', $item['cantidaddiferencia'])
                    ->set('importealternativo', '? * precioalternativo', $item['cantidaddiferencia'])
                    ->where('idmovimiento = ?', $item['idmovimiento'])->execute();
            }
        }
        return true;
    }
    
    private function tryInyector()
    {
        $relations[] = array(
            'cardinalidad' => 'one', 'relation' => 'DatReclamacion',
            'properties' => array('local' => 'iddocumento', 'foreign' => 'iddocumento')
        );
        $relations[] = array(
            'cardinalidad' => 'one', 'relation' => 'DatRecepcion',
            'properties' => array('local' => 'iddocumento', 'foreign' => 'iddocumento')
        );
        $this->logisticaDoctrine->tryInyectRelactions(new DatDocumento(), $relations);
        $relations = array();
        $relations[] = array(
            'cardinalidad' => 'many', 'relation' => 'DatReclamacion',
            'properties' => array('local' => 'iddocumento', 'foreign' => 'iddocumento')
        );
        $relations[] = array(
            'cardinalidad' => 'many', 'relation' => 'DatRecepcion',
            'properties' => array('local' => 'iddocumento', 'foreign' => 'iddocumento')
        );
        $relations[] = array(
            'cardinalidad' => 'one', 'relation' => 'DatMovrecepcion',
            'properties' => array('local' => 'idmovimiento', 'foreign' => 'idmovimiento')
        );
        $relations[] = array(
            'cardinalidad' => 'one', 'relation' => 'DatMovdiferencia',
            'properties' => array('local' => 'idmovimiento', 'foreign' => 'idmovimiento')
        );
        $relations[] = array(
            'cardinalidad' => 'many', 'relation' => 'DatMovdiferenciacalidad',
            'properties' => array('local' => 'idmovimiento', 'foreign' => 'idmovimiento')
        );
        $this->logisticaDoctrine->tryInyectRelactions(new DatMovimientos(), $relations);
    }

}
