<?php

/**
 * @class      TransferenciareaModel
 *
 * @package Inventario
 * @subpackage Movimiento
 * @author Manuel Yhon Figueroa y Antonio Diaz Soutuyo
 * @copyright XETID
 * @version 1.0
 */
class TransferenciainternaModel extends MovimientosModel
{

    /**
     * @var UtilesubicacionService
     */
    private $ubicacion;
    private $logistEstrucUbica;

    public function __construct($datosDoc = array())
    {
        parent::__construct($datosDoc);
        $this->tryInyector();
        $this->ubicacion = new UtilesubicacionService();
        $this->logistEstrucUbica = LogisticaEstructuraUbicHelper::__init();
    }

    /**
     * Inyecta las relaciones entre clases.
     */
    private function tryInyector()
    {
        $relations[] = array(
            'cardinalidad' => 'one', 'relation' => 'DatTransferenciaAreas',
            'properties' => array('local' => 'iddocumento', 'foreign' => 'idtransferenciaarea')
        );
        $this->logisticaDoctrine->tryInyectRelactions(new DatDocumento(), $relations);

        $relations[] = array(
            'cardinalidad' => 'one', 'relation' => 'DatTransferenciaAreas',
            'properties' => array('local' => 'idtipotransferencia', 'foreign' => 'idtipotransferencia')
        );
        $this->logisticaDoctrine->tryInyectRelactions(new NomTipotransferencia(), $relations);

        $relations[] = array(
            'cardinalidad' => 'one', 'relation' => 'DatTransferenciaAreas',
            'properties' => array('local' => 'iddocumento', 'foreign' => 'iddocumento')
        );
        $this->logisticaDoctrine->tryInyectRelactions(new DatArea(), $relations);

        $relations[] = array(
            'cardinalidad' => 'many', 'relation' => 'DatTransferenciaAreas',
            'properties' => array('local' => 'iddocumento', 'foreign' => 'iddocumento')
        );
        $this->logisticaDoctrine->tryInyectRelactions(new DatMovimientos(), $relations);
    }

    /**
     * Metodo para devolver los documentos de trasnferencia entre areas
     * @params array $datosDoc Arreglo con los parametros para filtrar los
     * documentos
     *
     * @return array
     */
    public function devolverDocumentos($filtro)
    {
        $query = parent::devolverDocumentos($filtro);
        $trasnferenciareas = new DatTransferenciaAreas();
        $trasnferenciareas->getJoinDatTransferenciareas($query, 'd');
        $trasnferenciareas->getDatosTransferenciaareas($query, $filtro);
        return array(
            'cantidad' => $query->count(),
            'datos' => $this->logisticaDoctrine->addQueryLimits($query, $filtro)->fetchArray()
        );
    }

    /**
     * Elimina el documento seleccionado.
     * @param numeric $iddocumento
     * @return boolean
     */
    public function eliminarDocumento($iddocumento)
    {
        Doctrine_Query::create()->delete('DatUbicacionComprometida')->where('iddocumento = ?', $iddocumento)->execute();
        return parent::eliminarDocumento($iddocumento);
    }

    public function aprobarDocumento($iddocumento)
    {
        $cronologia = parent::aprobarDocumento($iddocumento, true);
        $this->doctrineHelper->getConnection()
            ->execute("SELECT mod_logfarmacia.f_aprobartransfinterna({$iddocumento}, {$cronologia})");
        (new LogisticaProductoModel())->aprobarMovimientos($iddocumento, $cronologia, true, true, false, true, LogisticaMovimientoModel::SIGNO_MOV_SUMA);
        (new LogisticaProductoModel())->aprobarMovimientos($iddocumento, $cronologia, false, true, false, true, LogisticaMovimientoModel::SIGNO_MOV_RESTA);
        (new LoteService())->actualizarExistenciaLote($iddocumento, true, $cronologia, false, LogisticaMovimientoModel::SIGNO_MOV_SUMA);
        (new LoteService())->actualizarExistenciaLote($iddocumento, false, $cronologia, false, LogisticaMovimientoModel::SIGNO_MOV_RESTA);
		$result = Doctrine_Manager::connection()->fetchAll("SELECT iddeposdestino FROM mod_logfarmacia.dat_transfinterna WHERE idtransfinterna = {$iddocumento}");
		$estado = $this->logistEstrucUbica->estadoAlmacen($result[0]['iddeposdestino'])->fetchArray();
		$ok = true;
		if(empty($estado)){
			$ok = $this->abrirAlmacen($result[0]['iddeposdestino']);
		} else if($estado[0]['estado'] == 1){
			$ok = $this->abrirAlmacen($result[0]['iddeposdestino']);
		}
		return $ok;
		
    }

    public function abrirAlmacen($idDeposito)
    {
		$fecha = $this->configuracionHelper->getFechaContableSubsistema(
                $this->global->Estructura->idestructura, LogisticaGlobal::SUBSISTEMA_INV
            );
		return $this->logistEstrucUbica->abrirAlmacen($idDeposito,$fecha);
    }
 /**
     * Metodo para cargar las areas de origen y destino
     * @params Integer $iddeposito
     *
     * @return array
     */
    public function cargarAreasOrigenDestino($params)
    {
        $cEstructura = 'Estructura';
        $cEstructura = $this->global->$cEstructura->idestructura;
        $params['idpadre'] = $cEstructura;
        $sEstrComposicion = ServiciosEstructuraComposicionHelper::__init();

        $query = "Select distinct
              ntra.idtipotransfinternaarea as idtipotransfinternaarea, ntra.iddeposito as iddeposito
              from mod_logfarmacia.nom_tipotransfinternaarea ntra
              ";
        $where = "";
        if ($params['idtipotransfinterna']) {
            $where = " where ntra.idtipotransfinterna = {$params['idtipotransfinterna']}";
        }

        $result = LogisticaDoctrineHelper::__init()->getConnection()->execute($query . $where)->fetchAll(PDO::FETCH_OBJ);
        $datos = array();

        foreach ($result as $res) {
            $datos[] = $res->iddeposito;
        }

        $result = $sEstrComposicion->obtenerEstructurasNoFormales(
            $this->global->Perfil->certificado, $cEstructura, false, null, null, $datos
        );
        if ($params['destino']) {
            $conf = $this->cargarDatosConFarm();
            foreach ($result as $index => $datosresu) {
                if ($conf[0]['idretenido'] == $datosresu['idfila']) {
                    $result[$index]['retenido'] = 1;
                } else {
                    $result[$index]['retenido'] = 0;
                }
            }
        }

        return $result;
    }

    public function cargarDatosConFarm()
    {
        $cFechaContable = 'FechaContable';
        $fechaContable = $this->global->$cFechaContable->fecha;
        $cEstructura = 'Estructura';
        $cEstructura = $this->global->$cEstructura->idestructura;
        $select = "select *  from mod_logfarmacia.conf_generalfm where idestructura = $cEstructura";
        $datos = LogisticaDoctrineHelper::__init()->getConnection()->execute($select)->fetchAll();
        $datos[0]['fechacontable'] = $fechaContable;
        return $datos;
    }

    /**
     * Devuelve las areas del deposito.
     * @params numeric $iddeposito
     * @return array
     */
    public function cargarAreasXTipoTransferencia($iddeposito)
    {
        $query = $this->ubicacion->devolverAreasPorDeposito($iddeposito, true);
        $query->addSelect(
            "(SELECT array_to_string(array_agg(tt.idtipotransferencia), ',') FROM NomTipoarea ta "
            . "INNER JOIN ta.NomTipotransferenciaarea tta ON tta.idnomtipoarea = ai.idnomtipoarea "
            . "INNER JOIN tta.NomTipotransferencia tt ON tt.idtipotransferencia = tta.idtipotransferencia "
            . "WHERE ta.idnomtipoarea = ai.idnomtipoarea) AS idtipotransferencia"
        )
            ->innerJoin('a.DatAreainventario ai');
        return $query->fetchArray();
    }

    public function cargarCodificador($params, $sql = false)
    {
        $cEstructura = 'Estructura';
        $cEstructura = $this->global->$cEstructura->idestructura;
        
        $select = " select DISTINCT pp.cantidad as existencia, pp.precio as preciocosto, pp.precioventa, pp.idcodificador, pp.idproducto,
        pp.idlineaprod, lp.denominacion as denomlineaprod, co.codigo, co.descripcion as denominacion, tem.denominacion as presentacion,
        umm.abreviaturaunidadmedida as uemb,h.tipocontrol,
        (select idmovimiento from mod_logistica.dat_movimiento where idproducto = pp.idproducto
        order by cronologia desc limit 1) as idmovimiento
        /*,
        (select existenciaactual from mod_logistica.dat_movimiento where idproducto = pp.idproducto
        order by cronologia desc limit 1) as existencia*/
        ";
        $from = " from mod_logistica.dat_producto pp
        inner join mod_datosmaestros.dat_codificador co on co.idcodificador = pp.idcodificador
        inner join mod_datosmaestros.nom_indicadorhoja h on h.idindicador = co.idindicador
        inner join mod_logfarmacia.nom_lineaprod lp on lp.idlineaprod = pp.idlineaprod
        left join mod_datosmaestros.nom_tipoenvase tem on tem.idtipoenvase = co.idpresentacion
        left join mod_datosmaestros.nom_unidadmedida umm on umm.idunidadmedida = pp.idumedida";

        $where = " where pp.idestructuracomun = {$cEstructura} and pp.cronologia > 0
        and pp.idestructura = {$params['iddeposorigen']}";
        if ($params['excluir']) {
            $excluir = implode(',', $params['excluir']);
            $where .= " and pp.idcodificador not in ($excluir)";
        }
        $where = $this->getFilter($params, 'co', $where);
        $total = LogisticaDoctrineHelper::__init()->getConnection()->execute(
            $select . $from . $where
        )->fetchAll();

        if ($params['limit']) {

            $offset = " offset({$params['start']}) limit({$params['limit']})";

        }

        $orderBy = " ORDER BY denomlineaprod ASC, denominacion ASC";
        
        if ($sql) {
            return array($select, $from, $where, $offset, $orderBy);
        } else {
            $datos = LogisticaDoctrineHelper::__init()->getConnection()->execute(
                $select . $from . $where . $orderBy . $offset
            )->fetchAll();

            return array($datos, count($total));
        }

    }

    public function cargarLoteAdd($params)
    {
        $iddoc = $this->getIddoc();
        $cEstructura = 'Estructura';
        $cEstructura = $this->global->$cEstructura->idestructura;
        $select = " select l.idlote, l.idproducto,l.fechafabricacion, l.fechavencimiento, l.existencia as cantidad,
        l.numero as nrolote,
        (
            select estr.descripcion as ubicacion
            from mod_logistica.dat_producto ppp
            inner join mod_logistica.dat_lote ll on ll.idproducto = ppp.idproducto
            inner join mod_logistica.dat_movlote m on m.idlote = ll.idlote
            inner join mod_logistica.dat_movimiento mov on mov.idmovimiento = m.idmovimiento
            left join mod_logubicacion.dat_estructuraubicacion estr on estr.idestructuraubicacion = m.idubicacion
            where ppp.idestructuracomun = {$cEstructura} and mov.cronologia > 0
            order by mov.cronologia DESC limit 1
        ) as ubicacion
        ";
        $from = " from mod_logistica.dat_producto pp
        inner join mod_logistica.dat_lote l on l.idproducto = pp.idproducto";
        $where = " where pp.idestructuracomun = {$cEstructura} and l.idproducto = {$params['idproducto']}
            and l.cronologia > 0";
        $orderby = " order by l.fechavencimiento, l.existencia asc";
        if (count($params['excluir']) > 0) {
            $params['excluir'] = implode(',', $params['excluir']);
            $where .= " and l.idlote not in ({$params['excluir']})";
        }
        $where = $this->getFilter($params, 'l', $where);
		
        $total = LogisticaDoctrineHelper::__init()->getConnection()->execute(
            $select . $from . $where
        )->fetchAll();
        if ($params['limit']) {
            $orderby .= " offset({$params['start']}) limit({$params['limit']})";
        }

        $datos = LogisticaDoctrineHelper::__init()->getConnection()->execute(
            $select . $from . $where. $orderby
        )->fetchAll();

        if (count($datos) > 0) {
            foreach ($datos as $index => $dat) {
                $sql = "  select dd.estado, til.idlote, dd.cronologia 
                from mod_logistica.dat_documento dd
                inner join mod_logfarmacia.dat_transfinternalote til on til.idtransfinterna = dd.iddocumento
                ";

                $whereaux = " where dd.iddoc = {$iddoc} and dd.estado = 1 and til.idlote = {$dat['idlote']} ";
                if (count($params['excluir']) > 0) {
                    $whereaux .= " and til.idlote not in ({$params['excluir']})";
                }
                // print_r($sql. $whereaux);die;
                $result = LogisticaDoctrineHelper::__init()->getConnection()->execute(
                    $sql . $whereaux
                )->fetchAll();

                if (count($result) == 1) {
                    $datos[$index]['enuso'] = 1;
                } else {
                    $datos[$index]['enuso'] = 0;
                }
            }
        }
        return array($datos, count($total));
    }

    public function adicionarTransferanciaInterna($params)
    {
        $documento = new DocumentoLogisticaModel();
        $data = $params['data'];
        $obj = new DatTransfinterna();
        $doc = $documento->adicionarDocumento($data);
        $doc->iddoc = $this->getIddoc();
        $doc->save();


        if ($data['iddocumento']) {
            $data['idtransfinterna'] = $data['iddocumento'];
            $obj->assignIdentifier($data['idtransfinterna']);
            $obj->synchronizeWithArray($data);
        } else {
            $data['idtransfinterna'] = $obj->idtransfinterna = $doc->iddocumento;
            $obj->synchronizeWithArray($data);
        }
        $obj->save();
        $params['iddocumento'] = $doc->iddocumento;
        if (count($params['productos']) > 0) {
            $this->adicionarProductosTransfInterna($params);
        }

        if (count($params['lote']) > 0) {
            $this->guardarLote($params);
        }

        return $doc->toArray();
    }

    public function adicionarProductosTransfInterna($params)
    {
        if ($params['productos']) {
            $colection = new Doctrine_Collection("DatProdTransfInterna");

            foreach ($params['productos'] as $prod) {
                $prod['idtransfinterna'] = $params['iddocumento'];
                $obj = new DatProdTransfInterna();
                if ($prod['idprodtransfinterna']) {
                    $obj->assignIdentifier($prod['idprodtransfinterna']);
                }
                $obj->synchronizeWithArray($prod);
                $colection[] = $obj;
            }
            if (count($colection) > 0)
                $colection->save();
        }
    }

    public function cargarDocumentos($params)
    {
        $sql = " SELECT d.*, tm.*, su.nombreusuario as creadopor, sua.idusuario as aprobadopor
         ,op.denominacion as areaorigen,opp.denominacion as areadestino, tt.denominacion as text
         ,cc.denominacion as conceretenido, mot.denominacion as denommotivo,
         (
         select count(p.idtransfinterna) FROM mod_logfarmacia.dat_prodtransfinterna p
         where p.idtransfinterna = d.iddocumento
         ) as cantproductos";
        $from = " FROM mod_logfarmacia.dat_transfinterna tm
                 INNER JOIN mod_logistica.dat_documento d ON tm.idtransfinterna = d.iddocumento
                 LEFT JOIN mod_logfarmacia.nom_tipotransfinterna tt on tt.idtipotransfinterna = tm.idtipotransfinterna
                 LEFT JOIN mod_logfarmacia.nom_conceptorete cc on cc.idconceptorete = tm.idconcepretenido
                 LEFT JOIN mod_estructuracomp.nom_filaestruc f on f.idfila = tm.iddeposorigen
                 LEFT JOIN mod_estructuracomp.nom_filaestruc ff on ff.idfila = tm.iddeposdestino
                 LEFT JOIN mod_estructuracomp.dat_estructuraop op on op.idestructuraop = f.idfila
                 LEFT JOIN mod_estructuracomp.dat_estructuraop opp on opp.idestructuraop = ff.idfila
                 LEFT JOIN mod_seguridad.seg_usuario su ON d.idusuario = su.idusuario
                 LEFT JOIN mod_seguridad.seg_usuario sua ON d.aprobadopor = sua.idusuario
                 LEFT JOIN mod_logfarmacia.nom_motivodevolucion mot on mot.idmotivodevolucion = tm.idmotivodevolucion
                 ";
        $where = " WHERE (d.iddoc = {$this->getIddoc()} )and d.estado in (1, 2, 3)";

        $where = $this->getFilterDoc($where, $params);
        $orderBy = "ORDER BY d.iddocumento DESC  ";

        $conn = Zend_Registry::get('conexion');
//aqui
        $limit = " limit " . $params['limit'] . " offset " . $params['start'];

        $cantidad = $conn->fetchAll($sql . $from . $where . $orderBy);
        $result = $conn->fetchAll($sql . $from . $where . $orderBy . $limit);
        return array($result, count($cantidad));

    }

    public function getFilterDoc($where, $params)
    {
        if ($params['estado']) {
            $where .= " and d.estado = {$params['estado']}";
        }
        if ($params['idtipotransfinterna']) {
            $where .= " and tm.idtipotransfinterna = {$params['idtipotransfinterna']}";
        }
        if ($params['iddeposorigen']) {
            $where .= " and tm.iddeposorigen = {$params['iddeposorigen']}";
        }
        if ($params['iddeposdestino']) {
            $where .= " and tm.iddeposdestino = {$params['iddeposdestino']}";
        }
        if ($params['aprobadopor']) {
            $where .= " and d.aprobadopor = {$params['aprobadopor']}";
        }
        if ($params['creadopor']) {
            $where .= " and d.idusuario = {$params['creadopor']}";
        }
        if ($params['desde']) {
            $where .= " and d.fechacontable >= '{$params['desde']}'";
        }
        if ($params['hasta']) {
            $where .= " and d.fechacontable <= '{$params['hasta']}'";
        }

        return $where;
    }

    public function cargarProductosTransferanciaInterna($params)
    {
        if ($params['idtransfinterna']) {

            $cod = $this->cargarCodificador($params, true);

            $cod[0] .= " ,pr.idtransfinterna, pr.idprodtransfinterna, pp.importe as importetotal,
            (select coalesce(sum(dtil.cantpasar),0) 
            from mod_logfarmacia.dat_transfinternalote dtil 
            where dtil.idproducto = pp.idproducto and dtil.idtransfinterna = {$params['idtransfinterna']})
             as cantidad, 
             (
                 pp.precioventa * (select coalesce(sum(dtil.cantpasar),0) 
                from mod_logfarmacia.dat_transfinternalote dtil 
                where dtil.idproducto = pp.idproducto and dtil.idtransfinterna = {$params['idtransfinterna']}) 
                ) as importeventa,
                
                (
                 pp.precio * (select coalesce(sum(dtil.cantpasar),0) 
                from mod_logfarmacia.dat_transfinternalote dtil 
                where dtil.idproducto = pp.idproducto and dtil.idtransfinterna = {$params['idtransfinterna']}) 
                ) as importetotal
             
            ";
            $cod[1] .= " inner join mod_logfarmacia.dat_prodtransfinterna pr on pr.idproducto = pp.idproducto
                inner join mod_logistica.dat_documento d on d.iddocumento = pr.idtransfinterna

                ";
            $cod[2] .= " and d.iddocumento = {$params['idtransfinterna']}";


//            print_r($cod[0]. $cod[1]. $cod[2]. $orderBy. $cod[3]);die;

            $result = LogisticaDoctrineHelper::__init()->getConnection()->execute(
                $cod[0] . $cod[1] . $cod[2] . $cod[4] . $cod[3]
            )->fetchAll();

            $r = LogisticaDoctrineHelper::__init()->getConnection()->execute(
                $cod[0] . $cod[1] . $cod[2] . $cod[4]
            )->fetchAll();


            return array('datos' => $result, 'cantidad' => count($r));
        }
        return array('datos' => array(), 'cantidad' => 0);
    }

    public function getFilter($params, $alias, $where)
    {
        if ($params['codigo']) {
            $where .= " and $alias.codigo ilike '%{$params['codigo']}%'";
        }
        if ($params['denominacion']) {
            $where .= " and $alias.descripcion ilike '%{$params['denominacion']}%'";
        }

        if ($params['nrolote']) {
            $where .= " and $alias.numero ilike '%{$params['nrolote']}%'";
        }

        if ($params['criterio']) {
            
            $where .= " and co.descripcion ilike '%{$params['criterio']}%' or co.codigo like '%{$params['criterio']}%'";
        }


        return $where;
    }

    public function guardarLote($params)
    {
        if ($params['lote']) {
            $params['record'] = $params['lote'];
            unset($params['lote']);
        }
        if ($params['record']) {
            $colection = new Doctrine_Collection("DatTransfinternaLote");
            foreach ($params['record'] as $prod) {

                $prod['idtransfinterna'] = $params['iddocumento'];
                $prod['idprodtransfinterna'] = ($params['idprodtransfinterna']) ? $params['idprodtransfinterna'] : $prod['idprodtransfinterna'];
                $obj = new DatTransfinternaLote();

                if ($prod['idtransfinternalote']) {
                    $obj->assignIdentifier($prod['idtransfinternalote']);
                }

                $obj->synchronizeWithArray($prod);
                $colection[] = $obj;
            }
            if (count($colection) > 0)
                $colection->save();
        }
    }

    public function cargarLote($params)
    {
        $cEstructura = 'Estructura';
        $cEstructura = $this->global->$cEstructura->idestructura;
        $select = " select l.idlote, l.idproducto,l.fechafabricacion, l.fechavencimiento, l.existencia as cantidad,
        l.numero as nrolote, tl.idtransfinternalote, tl.cantpasar,
        (
            select estr.descripcion as ubicacion
            from mod_logfarmacia.dat_transfinternalote  tll
            --inner join mod_logistica.dat_lote  ll on ll.idlote = tll.idlote
            inner join mod_logistica.dat_movlote m on m.idlote = tll.idlote
            inner join mod_logistica.dat_movimiento mov on mov.idmovimiento = m.idmovimiento
            left join mod_logubicacion.dat_estructuraubicacion estr on estr.idestructuraubicacion = m.idubicacion
            where tll.idtransfinterna = {$params['iddocumento']} and mov.cronologia > 0
            order by mov.cronologia DESC limit 1
        ) as ubicacion


        ";
        $from = " from mod_logistica.dat_producto pp
        inner join mod_logistica.dat_lote l on l.idproducto = pp.idproducto
        inner join mod_logfarmacia.dat_transfinternalote  tl on tl.idlote =  l.idlote
        ";

        $where = " where pp.idestructuracomun = {$cEstructura} and tl.idtransfinterna = {$params['iddocumento']}";

        if ($params['idproducto']) {
            $where .= " and tl.idproducto = {$params['idproducto']}";
        }
        $where = $this->getFilter($params, 'l', $where);

        if (count($params['excluir']) > 0) {
            $params['excluir'] = implode(',', $params['excluir']);
            $where .= " and l.idlote not in ({$params['excluir']})";
        }
        $total = LogisticaDoctrineHelper::__init()->getConnection()->execute(
            $select . $from . $where
        )->fetchAll();
        if ($params['limit']) {
            $where .= " offset({$params['start']}) limit({$params['limit']})";
        }

        $datos = LogisticaDoctrineHelper::__init()->getConnection()->execute(
            $select . $from . $where
        )->fetchAll();

        return array($datos, count($total));
    }

    public function eliminarLote($params)
    {
        foreach ($params['arrlotedel'] as $dat) {
            Doctrine_Query::create()->delete('DatTransfinternaLote')
                ->where('idtransfinternalote = ?', $dat)->execute();
        }
    }

    public function eliminarProductosTransfInterna($params)
    {
        foreach ($params['arrelimprodlogica'] as $datos) {
            Doctrine_Query::create()->delete('DatProdTransfInterna')
                ->where('idprodtransfinterna = ?', $datos['idprodtransfinterna'])
                ->execute();
        }
    }

    public function getValidarConfirmar($params)
    {
        $select = " select (select coalesce(sum(dtil.cantpasar),0) 
        from mod_logfarmacia.dat_transfinternalote dtil 
        where dtil.idproducto = pp.idproducto and dtil.idtransfinterna = {$params['iddocumento']})
        as cantidad
        from mod_logfarmacia.dat_prodtransfinterna d
        inner join mod_logistica.dat_producto pp ON PP.idproducto = D.idproducto        
        WHERE d.idtransfinterna = {$params['iddocumento']}";
        $datos = LogisticaDoctrineHelper::__init()->getConnection()->execute(
            $select
        )->fetchAll();
        if (count($datos) == 0) {
            return array("msg" => 1); // para cuando no hay producto
        } else {

            $valorcero = $this->getForValidarConfirmar($params, $datos[0]);

            if ($valorcero == 'true') {
                return array("msg" => 2); //para cuando hay productos con cantidad cero
            } else {
                // para validar los Lotes, la cantidad no puede estar en cero
                $selectLote = " select d.cantpasar as cantidad
                from mod_logfarmacia.dat_transfinternalote d                
                WHERE d.idtransfinterna = {$params['iddocumento']}";
                $datoslote = LogisticaDoctrineHelper::__init()->getConnection()->execute(
                    $selectLote
                )->fetchAll();
                if (count($datoslote) == 0) {
                    return array("msg" => 1); // para cuando no hay lote
                } else {
                    $valorcero = $this->getForValidarConfirmar($params, $datoslote);
                    if ($valorcero == 'true') {
                        return array("msg" => 2); //para cuando hay productos con cantidad cero
                    } else {
                        return array("msg" => 0);
                    }
                }
            }
        }
    }

    public function getForValidarConfirmar($params, $datos)
    {
        $valorncero = 'false';
        foreach ($datos as $dat) {
            if ($dat['cantidad'] == 0) {
                $valorncero = 'true';
                break;
            }
        }
        return $valorncero;
    }

}
