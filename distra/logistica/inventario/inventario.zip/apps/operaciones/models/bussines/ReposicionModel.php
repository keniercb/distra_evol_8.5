<?php
    /**
     * Created by PhpStorm.
     * User: kcumba
     * Date: 4/06/18
     * Time: 15:03
     */

    class ReposicionModel extends BaseModel
    {
        public function __construct()
        {
            parent::__construct(false);
        }

        public function getConfFarmacia(){
            $select = "select *  from mod_logfarmacia.conf_generalfm where idestructura = {$this->global->Estructura->idestructura}";//print_r($select);die;
            $datos = LogisticaDoctrineHelper::__init()->getConnection()->execute($select)->fetchAll(PDO::FETCH_ASSOC);
            return $datos;
        }

        public function cargarProductosReposicion($params){
            $confGeneral = $this->getConfFarmacia();
			$confGeneral[0]['minarea'] = ($confGeneral[0]['minarea']) ? $confGeneral[0]['minarea'] : 0;
            $arrWhere = array();
            $arrWhere[] = "cf.idalmacen = dp.idestructura";
            $arrWhere[] = "dp.idestructuracomun = {$this->global->Estructura->idestructura}";
            if($params['criterio']){
                $criterio = $params['criterio'];
                $arrWhere[] = "(dc.codigo ILIKE '%{$criterio}%' OR dc.descripcion ILIKE '%{$criterio}%')";
            }
            $where = implode(' AND ', $arrWhere);
            $sqlData = "select distinct dc.codigo,dc.descripcion, dp.cantidad as cantalmacen, drp.cantidad as cantidadrep,
          drp.idreposicion, cf.idareaventa as iddeposdestino, cf.idalmacen as iddeposorigen, coalesce((
          select sum(dpa.cantidad) from mod_logistica.dat_producto dpa
          where dpa.idcodificador = dp.idcodificador 
            and dp.idestructuracomun = dpa.idestructuracomun
            and dpa.idestructura = cf.idareaventa
        ),0) as cantidad, (select coalesce(dp1.maximo*{$confGeneral[0]['fondofijo']}/100,0) from mod_logistica.dat_producto dp1 
        where dp1.idcodificador = dp.idcodificador and dp1.idestructura = {$confGeneral[0]['idalmacen']} limit 1) as fondofijo,
        coalesce((select coalesce(dp2.maximo*{$confGeneral[0]['fondofijo']}/100,0) from mod_logistica.dat_producto dp2 
        where dp2.idcodificador = dp.idcodificador and dp2.idestructura = {$confGeneral[0]['idalmacen']}  limit 1) * {$confGeneral[0]['minarea']}/100,0) as minimoventa, dc.idcodificador,
        dp.idproducto as idproducto 
                  
        from mod_logistica.dat_producto dp
        inner join mod_datosmaestros.dat_codificador dc on dc.idcodificador = dp.idcodificador
        inner join mod_logfarmacia.conf_generalfm cf on cf.idestructura = dp.idestructuracomun 
        LEFT JOIN mod_loginventario.dat_reposicion drp on dc.idcodificador = drp.idcodificador
        where  $where order by dc.descripcion limit {$params['limit']} offset {$params['start']}";

            $sqlCount = "select count(dp.idproducto) as cantidad from mod_logistica.dat_producto dp
            inner join mod_datosmaestros.dat_codificador dc on dc.idcodificador = dp.idcodificador
            inner join mod_logfarmacia.conf_generalfm cf on cf.idestructura = dp.idestructuracomun 
            LEFT JOIN mod_loginventario.dat_reposicion drp on dc.idcodificador = drp.idcodificador
            where  $where";
			//print_r($sqlData);die;
            return array(
                'datos' => $this->doctrineHelper->getConnection()->fetchAll($sqlData),
                'cantidad' => $this->doctrineHelper->getConnection()->fetchAll($sqlCount)[0]['cantidad'],
            );

        }
		/*
		( SELECT dpp.idproducto  from mod_logistica.dat_producto dpp WHERE dpp.idcodificador = dc.idcodificador 
          AND idestructura = cf.idalmacen )
		*/

        public function guardarReposicion($paramas)
        {

            if($paramas['valoresareponer']) {
                $datos = Zend_Json::decode($paramas['valoresareponer']);
                $coleccion =  new Doctrine_Collection("DatReposicion");

                foreach($datos as $dat) {
                    $repo = new DatReposicion();
                    if($dat['idreposicion']) {
                        $repo->assignIdentifier($dat['idreposicion']);
                    }
                    $repo->cantidad = $dat['cantidadrep'];
                    $repo->idcodificador = $dat['idcodificador'];
                    $coleccion->add($repo);
                }
                $coleccion->save();
            }
        }

        public function reponer($parametros)
        {

            $arrayData = array('alias' => 'transferenciainternaLog', 'subsistema' => LogisticaGlobal::SUBSISTEMA_INV);
            $transf = new TransferenciainternaModel($arrayData);
            $param['productos'] = Zend_Json::decode($parametros['productos']);
            //Buscando el tipo de transferencia interna
            $tipotransf = $this->doctrineHelper->getConnection()->fetchAll(" SELECT idtipotransfinterna 
                FROM mod_logfarmacia.nom_tipotransfinterna WHERE pordefecto = 1");
            if (count($tipotransf)) { //si existe el tipo de transf interna ..
                $idTipotransf = $tipotransf[0]['idtipotransfinterna'];
                $iddeposorigen =  $param['productos'][0]['iddeposorigen'];
                $iddeposdestino =  $param['productos'][0]['iddeposdestino'];
                $param['data'] = array(
                    'iddeposorigen'=>$iddeposorigen, 'iddeposdestino'=>$iddeposdestino,
                    'idtipotransfinterna'=> $idTipotransf
                );
                $doc = $transf->adicionarTransferanciaInterna($param);

                //Gestionar los lotes de donde se van a sacar los productos
                $lotesSalvar = array();
                $idEstructura = $this->global->Estructura->idestructura;
                foreach ($param['productos'] as $index =>$prod) {

                    //De cada producto buscar los lotes que suplan la cantidad que se necesita.
                    $sqlLotes = " select l.idlote, l.idproducto,l.fechavencimiento, l.existencia as cantidad
                        from mod_logistica.dat_producto pp
                        inner join mod_logistica.dat_lote l on l.idproducto = pp.idproducto 
                        where pp.idestructuracomun = {$idEstructura} and l.idproducto = {$prod['idproducto']}
                        ORDER BY l.fechavencimiento DESC ";
                    $lotes = $this->doctrineHelper->getConnection()->fetchAll($sqlLotes);

                    if(count($lotes))
                    {
                        for ($i = 0; $i < count($lotes) && $prod['cantidadrep'] > 0; $i++)
                        {
                            $sqlProdTransf = " SELECT pr.idprodtransfinterna 
                            FROM mod_logfarmacia.dat_prodtransfinterna pr  WHERE pr.idproducto = {$prod['idproducto']} 
                            AND pr.idtransfinterna = {$doc['iddocumento']}";
                            $prodDoc = $this->doctrineHelper->getConnection()->fetchAll($sqlProdTransf);

                            $lot = array(
                                'idtransfinterna' => $doc['iddocumento'],
                                'idprodtransfinterna' => $prodDoc[0]['idprodtransfinterna'],
                                'idproducto' => $prod['idproducto'], 'idlote' => $lotes[$i]['idlote']
                            );
                            if ($prod['cantidadrep'] > $lotes[$i]['cantidad']) {
                                $lot['cantpasar'] = $lotes[$i]['cantidad'];
                                $prod['cantidadrep'] = $prod['cantidadrep'] - $lotes[$i]['cantidad'];
                                $lotesSalvar[] = $lot;
                            } else {
                                $lot['cantpasar'] = $prod['cantidadrep'];
                                $prod['cantidadrep'] = 0;
                                $lotesSalvar[] = $lot;
                            }
                            $param['productos'][$index] = $prod;
                        }
                        $param['valoresareponer'] = Zend_Json::encode($param['productos']);
                        $this->guardarReposicion($param);
                    } else {
                        //Controlar los que no se encontraron lotes para la transferencia.
                    }
                }
                $param['iddocumento'] = $doc['iddocumento'];
                $param['lote'] = $lotesSalvar;
                $transf->guardarLote($param);
                $transf->confirmarDocumento($doc['iddocumento']);
                $transf->aprobarDocumento($doc['iddocumento']);
                $documentoT = Doctrine::getTable('DatDocumento')
                    ->findBy('iddocumento',$doc['iddocumento'], Doctrine_Core::HYDRATE_ARRAY);
                return array('nrodoc'=>$documentoT[0]['nrodoc'], 'fechacontable'=>$documentoT[0]['fechacontable']);
            } else {
                return array('msg'=>"Debe configurar el tipo de transferencia para dicha operaci\xf3n");
            }

        }

    }