<?php

class ExistenciaproductosModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();
    }

    public function cargarProductos($filtro)
    {
        $orderby = "";
        $espacialidades = $this->objectHelper->extractValueFromArrayColumn(
            $this->configuracionHelper->obtenerEspecialidades(array('restringir' => true)), 'idespecialidad'
        );
        if (count($espacialidades) == 0) {
            throw new ZendExt_Exception('LOG_INV_Prod_Exist_001');
        }
        if ($filtro['detalles']) {
            $select = ", dp.idestructura, coalesce (e.codigo || ' - ' || e.denominacion,e.denominacion) as entidad, coalesce (eop.codigo || ' - ' || eop.denominacion,eop.denominacion) as almacen, dp.precio as preciocontable, dp.precioalternativo, 
				(dp.cantidad - coalesce((SELECT sum(dcc.cantidad) FROM mod_logistica.dat_cantidadcomprometida dcc where dcc.idproducto = dp.idproducto and dcc.estado = 1),0)) as disponible,
                /*(select de.denominacion from mod_estructuracomp.v_dametodasestructuras de inner join mod_estructuracomp.dat_subordinacion ds on de.idestructura = ds.idpadre inner join mod_estructuracomp.nom_subordinacion ns on ns.denominacion = 'RESE' where ds.idhijo= dp.idestructuracomun limit 1)*/'' as delegacion, 
                /*(select e.denominacion from mod_estructuracomp.? n inner join mod_estructuracomp.v_dametodasestructuras e on e.idestructura = n.idfila where n.parent_path operator(public.@>) (select nf.parent_path from mod_estructuracomp.nom_filaestruc nf where nf.idfila = dp.idestructuracomun limit 1) order by n.idfila asc limit 1)*/'' as ministerio,
				(select uumm.abreviaturaunidadmedida from mod_datosmaestros.nom_unidadmedida uumm where uumm.idunidadmedida = dp.idumedida ) as umop";
            $join = "inner join mod_estructuracomp.v_dametodasestructuras e on e.idestructura = dp.idestructuracomun 
                inner join mod_estructuracomp.v_dametodasestructuras eop on eop.idestructura = dp.idestructura";
            $group = "dp.idestructuracomun, dp.idestructura,e.codigo, e.denominacion, eop.denominacion,eop.codigo,dp.cantidad,dp.idproducto,";
            $orderby = "e.denominacion, eop.denominacion, ";
        }
        if ($filtro['idindicador']) {
            $where = "and ni.idindicador = '{$filtro['idindicador']}'";
        }
        if ($filtro['naturaleza']) {
            $where = "and ni.idnaturaleza = '{$filtro['naturaleza']}'";
        }
//        if ($filtro['idministerio']) {
//            $where = "and dp.idestructuracomun = '{$filtro['idministerio']}'";
//        }
        $filtro['identidad'] = $this->global->Estructura->idestructura;
        if ($filtro['idsubordinacion']) {
            $filtro['identidad'] = $filtro['idsubordinacion'];
        }
        $filtro['rol'] = $this->global->Perfil->idrol;
        if ($filtro['idnaturaleza']) {
            $where = "and ni.idnaturaleza = {$filtro['idnaturaleza']}";
        }
        if ($filtro['criterio']) {
            $where = "and (ni.numeropieza ILIKE '%{$filtro['criterio']}%' or ni.denominacion ILIKE '%{$filtro['criterio']}%')";
        }
		/**
		* TODO Cambiar este fragmento pues fueza q todos los usuarios vean el balance
		**/		
        //$filtro['rol'] = $this->global->Perfil->idrol;//(new VariablesGlobalesModel())->obtenerValor('ROL_EXIST');
        $filtro['idusuario'] = $this->global->Perfil->idusuario;//(new VariablesGlobalesModel())->obtenerValor('USUARIO_EXIST');
        //$filtro['identidad'] = $this->global->Estructura->idestructura;//(new VariablesGlobalesModel())->obtenerValor('ENTIDAD_EXIST');
		/**
		* END TODO Cambiar este fragmento pues fueza q todos los usuarios vean el balance
		**/
        $sql = "select ni.idindicador, ni.numeropieza as codigo, ni.denominacion as denominacion, sum(dp.cantidad) as cantidad, 
            nu.abreviaturaunidadmedida as um, ni.precio as preciocentral, ni.precioalternativo as preciocentralalt {$select},
            nat.codigo as naturaleza, count(*) OVER() as total 
            from mod_logistica.dat_producto dp 
            inner join mod_datosmaestros.nom_indicador ni on ni.idindicador = dp.idindicador 
            inner join mod_datosmaestros.nom_unidadmedida nu on nu.idunidadmedida = dp.idumedida 
            inner join mod_datosmaestros.nom_naturaleza nat on nat.idnaturaleza = ni.idnaturaleza
            {$join} 
            where ni.idespecialidad in (select ce.idespecialidad from mod_logistica.conf_usuarioespecialidad ce where ce.idusuario = {$filtro['idusuario']} limit 1) {$where} 
            and dp.idestructuracomun in (select f.idfila from mod_estructuracomp.nom_filaestruc f where f.accesofila[(SELECT eur.identidad from mod_seguridad.dat_entidadusuariorol eur where eur.idusuario = {$filtro['idusuario']} and eur.idrol = {$filtro['rol']} limit 1)::numeric] = 1::bit) 
            and dp.cronologia > 0 and dp.idestructuracomun in (select  ds.idhijo from  mod_estructuracomp.dat_subordinacion ds where ds.parent_path operator(public.<@) (select ds.parent_path from  mod_estructuracomp.dat_subordinacion ds inner join mod_estructuracomp.nom_subordinacion ns on ns.denominacion = 'RESE' where ds.idhijo = {$filtro['identidad']} limit 1)) 
            group by {$group} ni.idindicador, ni.numeropieza, ni.denominacion, nu.abreviaturaunidadmedida, dp.idumedida, nat.codigo 
            having sum(dp.cantidad) > 0
            order by {$orderby} ni.numeropieza";//
            
            $datos = Doctrine_Manager::connection()->fetchAll(
                $sql . " offset ? limit ?", array($filtro['start'], $filtro['limit'])
            );
        return array(
            'cantidad' => $datos[0]['total'],
            'datos' => $datos
        );
    }
    
    public function exportarExcel($filtro)
    {
        unlink("tmp/");
        mkdir('tmp');
        $semilla = mktime();
        $fichero = "tmp/{$semilla}_informe.xls";
        $excel = new ExcelWriter($fichero);
        $datos = $this->cargarProductos($filtro);
        $columns = array(
            array('header' => 'Entidad', 'dataIndex' => 'entidad'),
            array('header' => 'Almac&eacute;n', 'dataIndex' => 'almacen'),
            array('header' => 'C&oacute;digo', 'dataIndex' => 'codigo'),
            array('header' => 'Naturaleza', 'dataIndex' => 'naturaleza'),
            array('header' => 'Producto', 'dataIndex' => 'denominacion'),
            array('header' => 'UM', 'dataIndex' => 'um'),
            array('header' => 'Cantidad', 'dataIndex' => 'cantidad'),
            array('header' => 'Disponible', 'dataIndex' => 'disponible'),
            array('header' => 'Precio CUP', 'dataIndex' => 'preciocontable'),
            array('header' => 'Precio CUC', 'dataIndex' => 'precioalternativo')
        );
        $excel->writeData($datos['datos'], $columns);
        $excel->close();
        return '/logistica/inventario/recuperaciones/' . $fichero;
    }
    
    public function cargarMinisterios($filtro)
    {
        return array();
    }
    
    public function cargarSubordinacion($filtro)
    {
        $sql = "SELECT q->>'id' AS id, q->>'denominacion' AS text, q->>'icon' AS icon, cast(q->>'leaf' AS bool) AS leaf "
            . "FROM mod_loginventario.f_107cargararbol({$filtro['idestructura']}, "
            . "{$this->global->Perfil->idusuario}, {$this->global->Perfil->idrol}, 3, null) q;";
        return Doctrine_Manager::connection()->fetchAll($sql);
    }

}
