LOG.inv.cambioclasificacioncontable.Loader = {
    init: function(cb) {
        var loader = new Ext.ux.ScriptManager();
        loader.loadJs({
            scripts: [
                '/configuracion/nomgenerales/views/js/comun/comboNomenclador.component.js'
            ],
            debug: true,
            callback: cb
        });
    }
};
LOG.inv.cambioclasificacioncontable.Loader.init();

UCID.portal.cargarAcciones(window.frameElement.id, function() {
    var idioma = LOG.util.UIManager.apply(LOG.util.Idioma.init(), LOG.inv.cambioclasificacioncontable.Idioma);
    var cambioclasificacioncontable = new LOG.inv.cambioclasificacioncontable.View({
        acciones: acciones_reportes,
        busquedaAvanzada: true,
        idioma: idioma
    });
    cambioclasificacioncontable.attachPlugin(new LOG.lb.plugin.ComboDepositos());
    cambioclasificacioncontable.attachPlugin(new LOG.lb.documento.PluginFirmaDocumentos({
        columnas : 2,
        firmas: [
            'creadopor',
            'aprobadopor'
        ]
    }));
    cambioclasificacioncontable.init();
    cambioclasificacioncontable.view();
});
