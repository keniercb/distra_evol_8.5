UCID.portal.cargarAcciones(window.frameElement.id, function () {
    var vistaTransferenciainterna = new LOG.inv.transferenciainterna.View({
        acciones: acciones_reportes,
        busquedaBasica: true,
        busquedaAvanzada: true,
        idioma: LOG.util.UIManager.apply(LOG.inv.transferenciainterna.Idioma, LOG.util.Idioma)
    });
   /* vistaTransferenciainterna.attachPlugin(new LOG.lb.plugin.ComboDepositos({
    caso : 3
}));*/
    vistaTransferenciainterna.init();
    vistaTransferenciainterna.getPanelBusqueda().setColumns(1);

    var fpDatosBusqueda = LOG.util.UIManager.initColumnForm({
        columnas: 2
    });


    fpDatosBusqueda.addComponent(new LOG.util.ComboBox({
        fieldLabel: vistaTransferenciainterna.idioma.lbEstado,
        hiddenName: 'estado',
        store: new Ext.data.SimpleStore({
            fields: ['idestado', 'estado'],
            data: [
                [1, LOG.lb.documento.Estado[1]],
                [2, LOG.lb.documento.Estado[2]],
                [3, LOG.lb.documento.Estado[3]]//,
              //  [5, LOG.lb.documento.Estado[5]]
            ]
        }),
        valueField: 'idestado',
        displayField: 'estado',
        editable: true
    }));


    fpDatosBusqueda.addComponent(new Ext.erp.comboNomenclador({
        controller: '/logistica/utiles/nomencladores/index.php/nomencladores/',
        modelo: 'NomTipotransfinterna',
        idnom: 'idtipotransfinterna',
        name: 'idtipotransfinterna',
        hiddenName: 'idtipotransfinterna',
        autoCargar: true,
        disable: true,
        allowBlank: true,
        fieldLabel: vistaTransferenciainterna.idioma.lbCbTipoTransferenciaArea,
        listeners: {
            select: function (_cb, _r) {
                cmbAreaOrigen.fireEvent('expand', cmbAreaOrigen);
                cmbAreaOrigen.setValue(null);
                cmbAreaOrigen.enable();

                cmbAreaOrigen.getStore().load({
                    params:{
                        idtipotransfinterna: _cb.getValue()
                    }
                });
                // _this.cbAreaDestino.fireEvent('expand', _this.cbAreaDestino);
                //_this.cbAreaDestino.setValue(null);
                // _this.cbAreaDestino.enable();
               // console.info(vistaTransferenciainterna);
            },
            'change': function(field){
                cmbAreaOrigen.fireEvent('expand', cmbAreaOrigen);
                cmbAreaOrigen.setValue(null);
                cmbAreaOrigen.enable();
                cmbAreaOrigen.getStore().load({
                    params:{
                        idtipotransfinterna: field.getValue()
                    }
                });
            }
        }
    }));

    var stAreasOrigenDestino = new Ext.data.Store({
        url: 'cargarAreasOrigenDestino',
        reader: new Ext.data.JsonReader({
                id: "idfila",

                root: "datos"
            },
            [
                {name: 'idfila'},
                {name: 'text'},
                {name: 'retenido'},
                {name: 'iddeposorigen'},
                {name: 'iddeposdestino'},
            ])
    });

    var cmbAreaOrigen = new LOG.util.ComboBox({
        fieldLabel: vistaTransferenciainterna.idioma.lbAreaOrigen,
        store: stAreasOrigenDestino,
        valueField: 'idfila',
        displayField: 'descripcion',
        name: 'iddeposorigen',
        hiddenName: 'iddeposorigen',
        displayField: 'text',
        disable: true,
        editable: false,
        listeners:{
            'change':function(field, newValue, oldValue){
                if (field.getValue()) {
                   cmbAreaDestino.enable();
                }
                if (cmbAreaDestino.getValue() == field.getValue()) {
                    mostrarMensaje(3, vistaTransferenciainterna.idioma.msgErrorSelecCombo);
                    field.reset();
                }

            },'select':function(cmb, rec){
                cmbAreaDestino.enable();
                var bandera = false;
                if (cmbAreaDestino.getValue() == cmb.getValue()) {
                    mostrarMensaje(3, vistaTransferenciainterna.idioma.msgErrorSelecCombo);
                    cmb.reset();
                    bandera = true;
                }
            }

        }
    });

    fpDatosBusqueda.addComponent(cmbAreaOrigen);


    var cmbAreaDestino = new LOG.util.ComboBox({
        fieldLabel: vistaTransferenciainterna.idioma.lbAreaDestino,
        store: stAreasOrigenDestino,
        valueField: 'idfila',
        displayField: 'text',
        name: 'iddeposdestino',
        hiddenName: 'iddeposdestino',
        disable: true,
        editable: false,
        listeners:{
            'select': function(cmb, rec){
                if (cmbAreaOrigen.getValue() == cmb.getValue()) {
                    mostrarMensaje(3, vistaTransferenciainterna.idioma.msgErrorSelecCombo);
                    cmb.reset();
                }
            }
        }
    });

    fpDatosBusqueda.addComponent(cmbAreaDestino);

    fpDatosBusqueda.addComponent(new LOG.lb.documento.ComboUsuarios({
        fieldLabel: vistaTransferenciainterna.idioma.lbCreadoPor,
        hiddenName: 'creadopor',
        alias: 'transferenciaLog',
        subsistema: 10
    }));

    fpDatosBusqueda.addComponent(new LOG.lb.documento.ComboUsuarios({
        fieldLabel: vistaTransferenciainterna.idioma.lbAprobadoPor,
        hiddenName: 'aprobadopor',
        alias: 'transferenciaLog',
        subsistema: 10
    }));

    /*fpDatosBusqueda.addComponent(new Ext.erp.comboNomenclador({
        controller: '/logistica/utiles/nomencladores/index.php/nomencladores/',
        modelo: 'NomLineaProductoFarm',
        idnom: 'idlineaprod',
        name: 'denominacion',
        autoCargar: true,
        allowBlank: false,
        disabled: false,
        fieldLabel: vistaTransferenciainterna.idioma.lbLineaprod
    }));*/

    var fpFechas = LOG.util.UIManager.initColumnForm({
        columnas: 2
    });

    fpFechas.addComponent(new Ext.form.DateField({
        fieldLabel: vistaTransferenciainterna.idioma.lbDesde,
        name: 'desde',
        xtype: 'datefield',
        vtype: 'daterange',
        format: 'd/m/Y',
        id: 'desde',
        endDateField: 'hasta',
        editable: false,
        getValue : function(){
            var dat = this.parseDate(Ext.form.DateField.superclass.getValue.call(this));
            if(dat instanceof Date){
                return dat.format(this.format);
            }
            return dat || "";
        }
    }));
    var hasta = new Ext.form.DateField({
        fieldLabel: vistaTransferenciainterna.idioma.lbHasta,
        name: 'hasta',
        xtype: 'datefield',
        vtype: 'daterange',
        id: 'hasta',
        format: 'd/m/Y',
        startDateField: 'desde',
        editable: false,
        getValue : function(){
            var dat = this.parseDate(Ext.form.DateField.superclass.getValue.call(this));
            if(dat instanceof Date){
                return dat.format(this.format);
            }
            return dat || "";
        }
    });
    fpFechas.addComponent(hasta);

    vistaTransferenciainterna.addFilterComponent(fpDatosBusqueda);
    vistaTransferenciainterna.addFilterComponent(new Ext.form.FieldSet({
        title: vistaTransferenciainterna.idioma.tlRangoFecha,
        items: [fpFechas]
    }));

    vistaTransferenciainterna.cbTipoTransferencia = new Ext.erp.comboNomenclador({
        fieldLabel: vistaTransferenciainterna.idioma.lbCbTipoTransferenciaArea,
        controller: '/logistica/utiles/nomencladores/index.php/nomencladores/',
        modelo: 'NomTipotransfinterna',
        idnom: 'idtipotransfinterna',
        name: 'idtipotransfinterna',
        hiddenName: 'idtipotransfinterna',
        autoCargar: true,
        allowBlank: false,
        mode: 'remote',
        emptyText: vistaTransferenciainterna.idioma.lbSeleccione,
        combo: true,
        listeners: {
            select: function (_cb, _r) {
                vistaTransferenciainterna.cbAreaOrigen.fireEvent('expand', vistaTransferenciainterna.cbAreaOrigen);
                vistaTransferenciainterna.cbAreaOrigen.setValue(null);
                vistaTransferenciainterna.cbConceptoRetenido.setValue(null);
                vistaTransferenciainterna.cbAreaDestino.setValue(null);

                vistaTransferenciainterna.cbAreaDestino.disable();
                vistaTransferenciainterna.cbConceptoRetenido.disable();
                vistaTransferenciainterna.cbAreaOrigen.enable();

                vistaTransferenciainterna.cbAreaOrigen.getStore().load({
                    params:{
                        idtipotransfinterna: vistaTransferenciainterna.cbTipoTransferencia.getValue()
                    }
                });
            },
            'change': function(){
                vistaTransferenciainterna.cbAreaOrigen.fireEvent('expand', vistaTransferenciainterna.cbAreaOrigen);

                vistaTransferenciainterna.cbAreaOrigen.setValue(null);
                vistaTransferenciainterna.cbConceptoRetenido.setValue(null);
                vistaTransferenciainterna.cbAreaDestino.setValue(null);

                vistaTransferenciainterna.cbAreaDestino.disable();
                vistaTransferenciainterna.cbConceptoRetenido.disable();
                vistaTransferenciainterna.cbAreaOrigen.enable();
                vistaTransferenciainterna.cbAreaOrigen.getStore().load({
                    params:{
                        idtipotransfinterna: vistaTransferenciainterna.cbTipoTransferencia.getValue()
                    }
                });
            }
        }
    });
    vistaTransferenciainterna.storigenDestino = new Ext.data.Store({
        url: 'cargarAreasOrigenDestino',
        autoLoad: true,
        reader: new Ext.data.JsonReader({
                id: "idfila",

                root: "datos"
            },
            [
                {name: 'idfila'},
                {name: 'text'},
                {name: 'retenido'},
                {name: 'iddeposorigen'},
                {name: 'iddeposdestino'},
            ])
    });
    vistaTransferenciainterna.cbAreaOrigen = new LOG.util.ComboBox({
        fieldLabel: vistaTransferenciainterna.idioma.lbCbAreaOrigen,
        store: vistaTransferenciainterna.storigenDestino,
        //url: 'cargarAreasOrigenDestino',
        name: 'iddeposorigen',
        hiddenName: 'iddeposorigen',
        valueField: 'idfila',
        displayField: 'text',
        editable: true,
        allowBlank: false,
        disabled: true,
        combo: true
    });
    vistaTransferenciainterna.cbConceptoRetenido = new Ext.erp.comboNomenclador({
        fieldLabel: vistaTransferenciainterna.idioma.lbCbConceptoRetenido,
        controller: '/logistica/utiles/nomencladores/index.php/nomencladores/',
        modelo: 'NomConceptoRetenido',
        idnom: 'idconceptorete',
        name: 'idconcepretenido',
        hiddenName: 'idconcepretenido',
        autoCargar: true,
        allowBlank: false,
        editable: false,
        emptyText: vistaTransferenciainterna.idioma.lbSeleccione,
        combo: true,
        disabled: true
    });
    vistaTransferenciainterna.cbAreaDestino = new LOG.util.ComboBox({
        fieldLabel: vistaTransferenciainterna.idioma.lbCbAreaDestino,
        //store: this.storDestino,
        store: vistaTransferenciainterna.storigenDestino,
        //url: 'cargarAreasOrigenDestino',
        name: 'iddeposdestino',
        hiddenName: 'iddeposdestino',
        valueField: 'idfila',
        displayField: 'text',
        editable: true,
        allowBlank: false,
        disabled: true,
        combo: true,
        listeners:{
            'select':function(cmb, rec){
                // console.info(rec);
                if (vistaTransferenciainterna.cbAreaOrigen.getValue() == cmb.getValue()) {
                    mostrarMensaje(3, vistaTransferenciainterna.idioma.msgErrorSelecCombo);
                    cmb.reset();
                }

                if (rec.data.retenido == 1) {
                    vistaTransferenciainterna.cbConceptoRetenido.enable();
                } else {
                    vistaTransferenciainterna.cbConceptoRetenido.disable();
                }
            }
        }
    });
    vistaTransferenciainterna.cbMotivoDevolucion = new Ext.erp.comboNomenclador({
        fieldLabel: vistaTransferenciainterna.idioma.lbCbMotivoDevolucion,
        controller: '/logistica/utiles/nomencladores/index.php/nomencladores/',
        modelo: 'NomMotivodevolucion',
        idnom: 'idmotivodevolucion',
        name: 'idmotivodevolucion',
        hiddenName: 'idmotivodevolucion',
        autoCargar: true,
        allowBlank: false,
        editable: false,
        disabled: true,
        emptyText: vistaTransferenciainterna.idioma.lbSeleccione,
        combo: true
    });

    vistaTransferenciainterna.view();

});