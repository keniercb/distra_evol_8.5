Ext.ns('Ext.erp.balancecontable');
Ext.erp.balancecontable = Ext.extend(LOG.util.UITemplate, {
    constructor: function(config) {
        var _this = this;
        config.dirController = '/logistica/inventario/recuperaciones/index.php/balancecontable';
        config.urlBusquedaGridPrincipal = 'cargarDatosPrincipales';
        config.modoSeleccion = 1;
        config.formaVisualizacion = 'panel';
        config.autoShow = true;
        config.autoLoad = true;
        config.idioma = {};

        Ext.erp.balancecontable.superclass.constructor.call(this, config);
        LOG.util.UIManager.apply(this.idioma, Log.inv.balancecontable.Idioma);
        _this.concepto = '';
        _this.textBusquedaSimple = ''/*this.idioma.txtBusquedaSimple*/;
    },
    initDefaultColumns: function() {
        this.addGridColumn({
            header: this.idioma.cgCuenta,
            width: 250,
            dataIndex: 'concatctax',
            default: true
        });
        this.addGridColumn(LOG.util.Prototipos.columnaImporte({
            header: this.idioma.cgValotContable,
            width: 120,
            dataIndex: 'saldo',
            align: 'right',
            default: true
        }));
        this.addGridColumn(LOG.util.Prototipos.columnaImporte({
            header: this.idioma.cgValorInventario,
            align: 'right',
            width: 120,
            dataIndex: 'valorinv',
            default: true
        }));
        this.addGridColumn(LOG.util.Prototipos.columnaImporte({
            header: 'Diferencia',
            align: 'right',
            width: 120,
            dataIndex: 'diff',
            default: true
        }));
    },
    initDefaultButtons: function() {
        var _this = this;
        this.addToolbarButton(new LOG.util.Prototipos.botonImprimir({
            tooltip: this.idioma.ttImprimir,
            disabled: true,
            handler: function() {
                _this.getReportes(_this);
            },
            controlFn: function(b, _caller) {
                _caller.getGridPrincipal().store.fireEvent = _caller.getGridPrincipal().store.fireEvent.createSequence(function(e) {
                    if (e == 'load') {
                        if (_caller.getStorePrincipal().getCount() != 0) {
                            b.enable();
                        } else {
                            b.disable();
                        }
                    }
                });
            }
        }));

        this.addToolbarButton(new LOG.util.Prototipos.botonGeneral({
            text: 'Movimientos por clasificaci\xf3n',
            handler: function() {
                var frmBusqueda = new LOG.util.ColumnForm({
                    columnas: 3,
                    region: 'center',
                    frame: true
                });

                frmBusqueda.addComponent(new Ext.erp.comboNomenclador({
                    controller: '/logistica/utiles/nomencladores/index.php/nomencladores/',
                    modelo: 'NomClasificacioncontablelog',
                    idnom: 'idclasificacioncontable',
                    name: 'denominacion',
                    autoCargar: true,
                    allowBlank: false,
                    fieldLabel: 'Clasificacion contable'
                }));
                frmBusqueda.addComponent(new Ext.form.DateField({
                    fieldLabel: 'Desde',
                    format: 'd/m/Y',
                    width: 150,
                    name: 'fechaini',
                    editable: false,
                    allowBlank: false,
                    maxValue: new Date(),
                }));
                frmBusqueda.addComponent(new Ext.form.DateField({
                    fieldLabel: 'Hasta',
                    format: 'd/m/Y',
                    width: 150,
                    name: 'fechafin',
                    editable: false,
                    allowBlank: false,
                    maxValue: new Date(),
                }));
                var formularioBusqueda = LOG.util.UIManager.initForm({
                    items: [frmBusqueda],
                    layout: 'border',
                    border: false,
                    region: 'center'
                });
                var win = new LOG.util.Window({
                    usarAplicar: false,
                    cerrarAceptar: false,
                    height: 150,
                    width: 450,
                    resizable: false,
                    autoValidate: true,
                    title: 'Filtros',
                    aceptarFn: function() {
                        var params = formularioBusqueda.getForm().getValues();
                        params.idestructura = idEntidad;
                        var tipoReportes = new LOG.util.Report({
                            reports: [{
                                    dirReport: '/distra/logistica/inventario/recuperaciones/MovimientosCuentaModelo',
                                    name: 'MovimientosCuentaModelo',
                                    isList: true,
                                    params: params
                                }]
                        });
                        tipoReportes.view();
                    },
                    items: [formularioBusqueda]

                });
                win.show();
            }
        }));
        /*this.comboDepositos = new LOG.util.LovCombo({
         mode: 'remote',
         url: _this.dirController + '/cargardepositos',
         displayField: 'deposito',
         valueField: 'iddeposito',
         autoLoad: false
         });
         this.lbDeposito = new Ext.form.Label({
         text: _this.idioma.lbDeposito
         });
         this.addToolbarButton("->");
         this.addToolbarButton(this.lbDeposito);
         this.addToolbarButton(" ");
         this.addToolbarButton(this.comboDepositos);*/
        this.dfFecha = new Ext.form.DateField({
            fieldLabel: _this.idioma.lbDfFecha,
            format: 'm/d/Y',
            width: 150,
            name: 'fechadocorigen',
            editable: false,
            maxValue: new Date(),
        });

         this.dfFecha.on({
             'select' : function(_df){
                 _this.storePrincipal.reload({
                     params: {
                         fecha: _this.dfFecha.getValue().format('d/m/Y')
                     }
                 });
             }
         });
        this.addToolbarButton("->");
        this.addToolbarButton("Fecha de cierre");
        this.addToolbarButton("-");
        this.addToolbarButton(this.dfFecha);
        this.addToolbarButton("-");
        this.addToolbarButton(new LOG.util.Prototipos.botonBuscar({
            handler: function() {
                _this.storePrincipal.reload({
                    params: {
                        fecha: _this.dfFecha.getValue().format('d/m/Y')
                    }
                });
            }
        }));
        this.addToolbarButton("-");
        this.addToolbarButton(new LOG.util.Prototipos.botonAyuda({id: 'idbalancecontable'}));


    },
    getReportes: function(data) {
        var _this = this;

        var tipoReportes = new LOG.util.Report({
            reports: [{
                    dirReport: '/distra/logistica/inventario/recuperaciones/BalanceContableModelo',
                    name: 'BalanceContableModelo',
                    isList: true,
                    params: {
                        idestructura: idEntidad,
                        fechafin: ((_this.dfFecha.getValue()) ? _this.dfFecha.getValue().format('d/m/Y') : null)
                    }
                }]
        });
        tipoReportes.view();
    },
    getDepositos: function() {
        var _this = this;
        _this.entidades = [];
        _this.entidadesCheck = _this.comboDepositos.getCheckedValue();
        for (var i = 0; i < _this.comboDepositos.store.data.items.length; i++) {
            _this.entidades.push(_this.comboDepositos.store.data.items[i].data.iddeposito);
        }
        var value = _this.entidadesCheck ? '{' + _this.entidadesCheck + '}' : '{' + _this.entidades + '}';
        return "'" + value + "'";
    },
    getCriterio: function() {
        return this.denominacion.getValue() || null;
    },
    botonBuscar: function() {
        if (this.denominacion.isDirty() || this.dias.isDirty()) {
            var _this = this;
            _this.getStorePrincipal().filtrado = true;
            _this.getStorePrincipal().load({
                params: {
                    valor: _this.dias.getValue(),
                    denominacion: _this.denominacion.getValue()
                }
            });
        }
    },
    customTriggerClear: function() {
        if (this.denominacion.isDirty() || this.dias.isDirty()) {
            var _this = this;
            _this.dias.reset();
            _this.denominacion.reset();

            _this.storePrincipal.on('beforeload', function(store) {
                store.baseParams = {
                    idestructura: idEntidad,
                    valor: 0,
                    denominacion: null,
                    start: 0,
                    limit: null
                };
            });
            _this.getStorePrincipal().load();
        }
    }

});